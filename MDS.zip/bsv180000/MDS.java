/**
 * Multi Dimensional Search
 * Searching for items in a large collection
 * @author Bhushan Vasisht bsv180000
 */

package bsv180000;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.*;

/**
 * Class for Multi Dimensional Search
 */
public class MDS {

    /**
     * Class: ItemProp
     * Description: Custom data structure used to store the price and the list of description ids for a product
     */
    static class ItemProp{
        Money price;
        List<Long> description;

        /**
         * Constructor for ItemProp
         * @param newPrice - new price of item - Money
         * @param newDescription - description of item - String
         */
        ItemProp(Money newPrice, List<Long> newDescription)
        {
            this.price = newPrice;
            this.description = new ArrayList<>(newDescription);
        }
    }

    /**
     * Hash Map to store the unique items
     * with keys of type Long and values are ItemProp objects.
     */
    Map<Long, ItemProp> storeMap;
    Map<Long, Set<Long>> descMap;

    /**
     * Constructor for MDS class to initialize
     */
    public MDS() {
        this.storeMap = new HashMap<>();
        this.descMap = new HashMap<>();
    }

    /**
     * Insert Method: Insert a new Item to the store
     * @param id
     * @param price
     * @param list
     * @return 1 for new item or return 0 for a replacement
     */
    public int insert(long id, Money price, java.util.List<Long> list) {
        int retVal = 1;

        //already present
        if(storeMap.containsKey(id)) {
            ItemProp value = storeMap.get(id);

            if(list.size()!=0) {
                for(long i: value.description) {
                    Set<Long> ts = descMap.get(i);
                    ts.remove(id);
                    if(ts.size()==0)
                        descMap.remove(i);
                    else
                        descMap.put(i, ts);
                }

                ArrayList<Long> newList = new ArrayList<>();

                for(long i: list) {
                    Set<Long> ts;
                    if(descMap.containsKey(i))
                        ts = descMap.get(i);
                    else
                        ts = new HashSet<Long>();
                    ts.add(id);
                    descMap.put(i, ts);
                    if(!newList.contains(i))
                        newList.add(i);
                }
                value.description = newList;
            }
            //update the price
            value.price = new Money(price.toString());
            storeMap.put(id, value);
            retVal= 0;
        }
        // if item is new
        else {
            ItemProp value = new ItemProp(price, list);

            ArrayList<Long> newList = new ArrayList<>();
            for(long i:list) {
                Set<Long> ts;
                if(descMap.containsKey(i))
                    ts = descMap.get(i);
                else
                    ts = new TreeSet<>();
                ts.add(id);
                descMap.put(i, ts);
                if(!newList.contains(i))
                    newList.add(i);
            }
            value.description = newList;
            //update the first map by inserting the values into it
            storeMap.put(id, value);
        }
        return retVal;
    }

    /**
     * Find Method: Find the price of an element of the given id
     * @param id
     * @return price for id if present else return 0
     */
    public Money find(long id) {
        if(storeMap.containsKey(id))
            return storeMap.get(id).price;
        //not found
        return new Money();
    }

    /**
     * Delete Method : Delete an item from the store
     * @param id
     * @return
     */
    public long delete(long id) {
        //not found
        if(!storeMap.containsKey(id)) return 0;

        ItemProp prop = storeMap.get(id);

        //remove reference from description map
        for(long it : prop.description)
        {
            descMap.get(it).remove(id);

            if(descMap.get(it).size() == 0)
                descMap.remove(it);
        }

        long sum = 0;
        for(long l : prop.description) {
            sum += l;
        }

        //remove the entry
        storeMap.remove(id);
        return sum;
    }

    /**
     * FindMinPrice method: Find the minimum prices Item
     * @param n
     * @return the minimum price in the matched items
     */
    public Money findMinPrice(long n) {
        if(!descMap.containsKey(n)) return new Money();

        Set<Long> ts = descMap.get(n);
        Money minM  = new Money(Long.MAX_VALUE, 0);

        for (long id : ts) {
            Money price = storeMap.get(id).price;
            if (minM.compareTo(price) > 0)
                minM = new Money(price.toString());
        }
        //return minPrice
        return minM;
    }

    /**
     * FindMaxPrice method: Find the maximum prices Item
     * @param n
     * @return the maximum price in the matched items
     */
    public Money findMaxPrice(long n) {
        if(!descMap.containsKey(n)) return new Money();

        Set<Long> ts = descMap.get(n);
        Money maxM  = new Money(Long.MIN_VALUE, 0);

        for (long id : ts) {
            Money price = storeMap.get(id).price;
            if (maxM.compareTo(price) < 0)
                maxM = new Money(price.toString());
        }
        //return maxPrice
        return maxM;
    }

    /**
     * findPriceRange Method : Find the number of items are in the range
     * @param n
     * @param low
     * @param high
     * @return
     */
    public int findPriceRange(long n, Money low, Money high) {
        //not found
        if(!descMap.containsKey(n)) return 0;

        int number = 0;
        Set<Long> ts = descMap.get(n);

        for(Long i: ts) {
            Money price = storeMap.get(i).price;
            if((price.compareTo(low) >= 1 || price.equals(low))  && (high.compareTo(price) <= 1 || price.equals(high)) )
                number++;
        }
        //return the number of product ids
        return number;
    }

    /***
     * Price Hike Method :Increase price for all th ematched ites by rate%
     * @param l
     * @param h
     * @param rate
     * @return
     */
    public Money priceHike(long l, long h, double rate) {
        double sum_of_increment = 0.0;
        for(long i = l; i <= h; ++i) {
            if(!storeMap.containsKey(i)) continue;

            ItemProp value = storeMap.get(i);
            Money price = value.price;
            String newMoney =  price.toString();
            double ActualMoney=Double.parseDouble(newMoney);
            double increase_rate = (100+rate)/100;
            double increase_money = increase_rate*ActualMoney;
            DecimalFormat df = new DecimalFormat("0.00");
            df.setRoundingMode(RoundingMode.DOWN);
            String FinalMoney = df.format(increase_money);
            increase_money = Double.parseDouble(FinalMoney);
            sum_of_increment = sum_of_increment + (increase_money - ActualMoney);
            Money newPrice = new Money(FinalMoney);
            value.price = newPrice;
            storeMap.put(i, value);
        }
        DecimalFormat df = new DecimalFormat("0.00");
        String netIncrease = df.format(sum_of_increment);
        Money netChange = new Money(netIncrease);
        //return the net increment that happened
        return netChange;
    }

    /*
      h. RemoveNames(id, list): Remove elements of list from the description of id.
      It is possible that some of the items in the list are not in the
      id's description.  Return the sum of the numbers that are actually
      deleted from the description of id.  Return 0 if there is no such id.
    */
    public long removeNames(long id, java.util.List<Long> list) {
        if(!storeMap.containsKey(id)) return 0;

        long sum = 0;
        ItemProp value = storeMap.get(id);
        List<Long> list1 = value.description;
        // for every element in the new list
        for(long i: list) {
            //check if it exists in the list of description ids for the product id
            if(list1.contains(i)) {
                sum += i;
                list1.remove(i);
                //for the description id , remove the product id from the list in the second map
                Set<Long> ts = descMap.get(i);
                ts.remove(id);
                if (ts.isEmpty())
                    descMap.remove(i);
                else
                    descMap.put(i, ts);
            }
        }
        value.description = new ArrayList<>(list1);
        //update the map with the new list
        storeMap.put(id, value);
        //return the sum pf the description ids that were deleted
        return sum;
    }

    /**
     * Money class
     */
    public static class Money implements Comparable<Money> {
        long d;  int c;

        /**
         * Default Constructor
         */
        public Money() { d = 0; c = 0; }

        public Money(long d, int c) { this.d = d; this.c = c; }

        public Money(String s) {
            String[] part = s.split("\\.");
            int len = part.length;
            if(len < 1) { d = 0; c = 0; }
            else if(part.length == 1) { d = Long.parseLong(s);  c = 0; }
            else { d = Long.parseLong(part[0]);  c = Integer.parseInt(part[1]); }
        }

        /***
         * return the amount of dollars
         * @return
         */
        public long dollars() { return d; }

        /**
         * return the amount of cents
         * @return
         */
        public int cents() { return c; }

        /***
         * CompareTo Method: Custom Object Comparator
         * @param other
         * @return
         */
        public int compareTo(Money other) { // Complete this, if needed
            if(this.d > other.d)
                return 1;
            else if (this.d < other.d)
                return 0;
            else {
                if(this.c > other.c)
                    return 1;
                else
                    return 0;
            }
        }

        /***
         * Equals Method : Check if two Money Objects are Equal
         * @param other
         * @return
         */
        public boolean equals(Money other) {
            if(this.d == other.d && this.c == other.c)
                return true;
            else
                return false;
        }

        /**
         * toString Method
         * @return
         */
        public String toString() {
            String cents = "0";
            if(c<10) {
                cents = cents + c;
                return d + "." + cents;
            }
            return d + "." + c;
        }
    }
}
